﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Prelab_03_152120231167_152120241075_Group5
{
    public partial class Form1 : Form
    {
        private DateTime baseTime;
        private Color dayColor = Color.Black;

        public Form1()
        {
            InitializeComponent();
            baseTime = DateTime.Now;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timerClock.Start();
        }

        private void timerClock_Tick(object sender, EventArgs e)
        {
            baseTime = baseTime.AddSeconds(1);
            DateTime displayTime = baseTime;

            if (cBoxTimeZone.SelectedItem is TimeZoneItem selectedZone)
            {
                displayTime = baseTime.AddHours(selectedZone.OffsetHours);
                ZoneLabel.Text = selectedZone.Name;
            }
            else
            {
                ZoneLabel.Text = "Default";
            }

            clockLabel.Text = displayTime.ToString("HH:mm:ss");

            if (displayTime.Hour >= 10 && displayTime.Hour < 23)
            {
                clockLabel.ForeColor = dayColor;
            }
            else
            {
                clockLabel.ForeColor = Color.Green;
            }
        }

        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            baseTime = new DateTime(baseTime.Year, baseTime.Month, baseTime.Day,
                dateTimePicker.Value.Hour, dateTimePicker.Value.Minute, dateTimePicker.Value.Second);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtZoneName.Text))
            {
                MessageBox.Show("Please enter a zone name.");
                return;
            }

            int offset = (int)numTimeDifference.Value;
            var newZone = new TimeZoneItem { Name = txtZoneName.Text, OffsetHours = offset };

            cBoxTimeZone.Items.Add(newZone);
            clbTimeZones.Items.Add(newZone);

            txtZoneName.Clear();
            numTimeDifference.Value = 0; // Reset spinner
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (clbTimeZones.CheckedIndices.Count == 1)
            {
                if (string.IsNullOrWhiteSpace(txtZoneName.Text))
                {
                    MessageBox.Show("Please enter a zone name.");
                    return;
                }

                int index = clbTimeZones.CheckedIndices[0];
                int offset = (int)numTimeDifference.Value;

                var updatedZone = new TimeZoneItem { Name = txtZoneName.Text, OffsetHours = offset };

                clbTimeZones.Items[index] = updatedZone;
                cBoxTimeZone.Items[index] = updatedZone;

                clbTimeZones.SetItemChecked(index, false);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = clbTimeZones.CheckedIndices.Count - 1; i >= 0; i--)
            {
                int indexToDelete = clbTimeZones.CheckedIndices[i];
                cBoxTimeZone.Items.RemoveAt(indexToDelete);
                clbTimeZones.Items.RemoveAt(indexToDelete);
            }
        }

        private void pickColorButton_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                dayColor = colorDialog1.Color;
            }
        }

        private void clbTimeZones_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            BeginInvoke((MethodInvoker)delegate
            {
                UpdateZoneButton.Enabled = clbTimeZones.CheckedItems.Count == 1;
            });
        }

        public class TimeZoneItem
        {
            public string Name { get; set; }
            public int OffsetHours { get; set; }

            public override string ToString()
            {
                return $"{Name} (UTC {OffsetHours:+0;-0;0})";
            }
        }

        private void clbTimeZones_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}