﻿namespace Prelab_03_152120231167_152120241075_Group5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.clockLabel = new System.Windows.Forms.Label();
            this.timerClock = new System.Windows.Forms.Timer(this.components);
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.pickColorButton = new System.Windows.Forms.Button();
            this.cBoxTimeZone = new System.Windows.Forms.ComboBox();
            this.txtZoneName = new System.Windows.Forms.TextBox();
            this.addZoneButton = new System.Windows.Forms.Button();
            this.UpdateZoneButton = new System.Windows.Forms.Button();
            this.deleteZoneButton = new System.Windows.Forms.Button();
            this.clbTimeZones = new System.Windows.Forms.CheckedListBox();
            this.ZoneLabel = new System.Windows.Forms.Label();
            this.labelZoneName = new System.Windows.Forms.Label();
            this.timeDiffLabel = new System.Windows.Forms.Label();
            this.numTimeDifference = new System.Windows.Forms.NumericUpDown();
            this.TimeZoneSelectText = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.numTimeDifference)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // clockLabel
            // 
            this.clockLabel.AutoSize = true;
            this.clockLabel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clockLabel.Font = new System.Drawing.Font("Niagara Engraved", 100.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clockLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.clockLabel.Location = new System.Drawing.Point(62, 26);
            this.clockLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.clockLabel.Name = "clockLabel";
            this.clockLabel.Size = new System.Drawing.Size(364, 178);
            this.clockLabel.TabIndex = 0;
            this.clockLabel.Text = "10:12:24";
            // 
            // timerClock
            // 
            this.timerClock.Enabled = true;
            this.timerClock.Interval = 1000;
            this.timerClock.Tick += new System.EventHandler(this.timerClock_Tick);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.CalendarMonthBackground = System.Drawing.SystemColors.InactiveCaption;
            this.dateTimePicker.CalendarTitleBackColor = System.Drawing.SystemColors.ControlLightLight;
            this.dateTimePicker.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker.Location = new System.Drawing.Point(31, 55);
            this.dateTimePicker.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.ShowUpDown = true;
            this.dateTimePicker.Size = new System.Drawing.Size(130, 30);
            this.dateTimePicker.TabIndex = 1;
            this.dateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker_ValueChanged);
            // 
            // pickColorButton
            // 
            this.pickColorButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pickColorButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pickColorButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickColorButton.Location = new System.Drawing.Point(31, 93);
            this.pickColorButton.Margin = new System.Windows.Forms.Padding(4);
            this.pickColorButton.Name = "pickColorButton";
            this.pickColorButton.Size = new System.Drawing.Size(130, 32);
            this.pickColorButton.TabIndex = 2;
            this.pickColorButton.Text = "Select Color";
            this.pickColorButton.UseVisualStyleBackColor = false;
            this.pickColorButton.Click += new System.EventHandler(this.pickColorButton_Click);
            // 
            // cBoxTimeZone
            // 
            this.cBoxTimeZone.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.cBoxTimeZone.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxTimeZone.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cBoxTimeZone.FormattingEnabled = true;
            this.cBoxTimeZone.Location = new System.Drawing.Point(191, 93);
            this.cBoxTimeZone.Margin = new System.Windows.Forms.Padding(4);
            this.cBoxTimeZone.Name = "cBoxTimeZone";
            this.cBoxTimeZone.Size = new System.Drawing.Size(130, 31);
            this.cBoxTimeZone.TabIndex = 3;
            // 
            // txtZoneName
            // 
            this.txtZoneName.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtZoneName.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtZoneName.Location = new System.Drawing.Point(20, 48);
            this.txtZoneName.Margin = new System.Windows.Forms.Padding(4);
            this.txtZoneName.Name = "txtZoneName";
            this.txtZoneName.Size = new System.Drawing.Size(117, 30);
            this.txtZoneName.TabIndex = 4;
            // 
            // addZoneButton
            // 
            this.addZoneButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.addZoneButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addZoneButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addZoneButton.Location = new System.Drawing.Point(305, 22);
            this.addZoneButton.Margin = new System.Windows.Forms.Padding(4);
            this.addZoneButton.Name = "addZoneButton";
            this.addZoneButton.Size = new System.Drawing.Size(78, 32);
            this.addZoneButton.TabIndex = 6;
            this.addZoneButton.Text = "Add ";
            this.addZoneButton.UseVisualStyleBackColor = false;
            this.addZoneButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // UpdateZoneButton
            // 
            this.UpdateZoneButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.UpdateZoneButton.Enabled = false;
            this.UpdateZoneButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UpdateZoneButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateZoneButton.Location = new System.Drawing.Point(305, 153);
            this.UpdateZoneButton.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateZoneButton.Name = "UpdateZoneButton";
            this.UpdateZoneButton.Size = new System.Drawing.Size(78, 32);
            this.UpdateZoneButton.TabIndex = 7;
            this.UpdateZoneButton.Text = "Update Zone";
            this.UpdateZoneButton.UseVisualStyleBackColor = false;
            this.UpdateZoneButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // deleteZoneButton
            // 
            this.deleteZoneButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.deleteZoneButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.deleteZoneButton.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteZoneButton.Location = new System.Drawing.Point(305, 87);
            this.deleteZoneButton.Margin = new System.Windows.Forms.Padding(4);
            this.deleteZoneButton.Name = "deleteZoneButton";
            this.deleteZoneButton.Size = new System.Drawing.Size(78, 32);
            this.deleteZoneButton.TabIndex = 8;
            this.deleteZoneButton.Text = "Delete";
            this.deleteZoneButton.UseVisualStyleBackColor = false;
            this.deleteZoneButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // clbTimeZones
            // 
            this.clbTimeZones.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.clbTimeZones.CheckOnClick = true;
            this.clbTimeZones.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbTimeZones.FormattingEnabled = true;
            this.clbTimeZones.Location = new System.Drawing.Point(20, 106);
            this.clbTimeZones.Margin = new System.Windows.Forms.Padding(4);
            this.clbTimeZones.Name = "clbTimeZones";
            this.clbTimeZones.Size = new System.Drawing.Size(253, 79);
            this.clbTimeZones.TabIndex = 9;
            this.clbTimeZones.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.clbTimeZones_ItemCheck);
            this.clbTimeZones.SelectedIndexChanged += new System.EventHandler(this.clbTimeZones_SelectedIndexChanged);
            // 
            // ZoneLabel
            // 
            this.ZoneLabel.AutoSize = true;
            this.ZoneLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ZoneLabel.Location = new System.Drawing.Point(229, 128);
            this.ZoneLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ZoneLabel.Name = "ZoneLabel";
            this.ZoneLabel.Size = new System.Drawing.Size(53, 23);
            this.ZoneLabel.TabIndex = 10;
            this.ZoneLabel.Text = "label1";
            // 
            // labelZoneName
            // 
            this.labelZoneName.AutoSize = true;
            this.labelZoneName.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelZoneName.Location = new System.Drawing.Point(16, 21);
            this.labelZoneName.Name = "labelZoneName";
            this.labelZoneName.Size = new System.Drawing.Size(100, 23);
            this.labelZoneName.TabIndex = 12;
            this.labelZoneName.Text = "Zone Name";
            // 
            // timeDiffLabel
            // 
            this.timeDiffLabel.AutoSize = true;
            this.timeDiffLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeDiffLabel.Location = new System.Drawing.Point(142, 22);
            this.timeDiffLabel.Name = "timeDiffLabel";
            this.timeDiffLabel.Size = new System.Drawing.Size(131, 23);
            this.timeDiffLabel.TabIndex = 14;
            this.timeDiffLabel.Text = "Time Difference";
            // 
            // numTimeDifference
            // 
            this.numTimeDifference.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.numTimeDifference.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold);
            this.numTimeDifference.Location = new System.Drawing.Point(146, 48);
            this.numTimeDifference.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.numTimeDifference.Minimum = new decimal(new int[] {
            14,
            0,
            0,
            -2147483648});
            this.numTimeDifference.Name = "numTimeDifference";
            this.numTimeDifference.Size = new System.Drawing.Size(127, 30);
            this.numTimeDifference.TabIndex = 15;
            // 
            // TimeZoneSelectText
            // 
            this.TimeZoneSelectText.AutoSize = true;
            this.TimeZoneSelectText.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimeZoneSelectText.Location = new System.Drawing.Point(187, 55);
            this.TimeZoneSelectText.Name = "TimeZoneSelectText";
            this.TimeZoneSelectText.Size = new System.Drawing.Size(141, 23);
            this.TimeZoneSelectText.TabIndex = 16;
            this.TimeZoneSelectText.Text = "Select Time Zone";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.clockLabel);
            this.panel1.Location = new System.Drawing.Point(25, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(407, 205);
            this.panel1.TabIndex = 17;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel2.Controls.Add(this.numTimeDifference);
            this.panel2.Controls.Add(this.timeDiffLabel);
            this.panel2.Controls.Add(this.labelZoneName);
            this.panel2.Controls.Add(this.clbTimeZones);
            this.panel2.Controls.Add(this.deleteZoneButton);
            this.panel2.Controls.Add(this.UpdateZoneButton);
            this.panel2.Controls.Add(this.addZoneButton);
            this.panel2.Controls.Add(this.txtZoneName);
            this.panel2.Location = new System.Drawing.Point(23, 250);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(408, 210);
            this.panel2.TabIndex = 18;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel3.Controls.Add(this.TimeZoneSelectText);
            this.panel3.Controls.Add(this.ZoneLabel);
            this.panel3.Controls.Add(this.cBoxTimeZone);
            this.panel3.Controls.Add(this.pickColorButton);
            this.panel3.Controls.Add(this.dateTimePicker);
            this.panel3.Location = new System.Drawing.Point(458, 27);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(352, 203);
            this.panel3.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(842, 485);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("High Tower Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numTimeDifference)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label clockLabel;
        private System.Windows.Forms.Timer timerClock;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button pickColorButton;
        private System.Windows.Forms.ComboBox cBoxTimeZone;
        private System.Windows.Forms.TextBox txtZoneName;
        private System.Windows.Forms.Button addZoneButton;
        private System.Windows.Forms.Button UpdateZoneButton;
        private System.Windows.Forms.Button deleteZoneButton;
        private System.Windows.Forms.CheckedListBox clbTimeZones;
        private System.Windows.Forms.Label ZoneLabel;
        private System.Windows.Forms.Label labelZoneName;
        private System.Windows.Forms.Label timeDiffLabel;
        private System.Windows.Forms.NumericUpDown numTimeDifference;
        private System.Windows.Forms.Label TimeZoneSelectText;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
    }
}

